var less = {};
less.rootpath = "https://www.github.com/cloudhead/less.js/";
less.relativeUrls = true;

